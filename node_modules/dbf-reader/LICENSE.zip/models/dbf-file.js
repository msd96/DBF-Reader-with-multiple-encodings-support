"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class DataTable {
    constructor() {
        this.columns = new Array();
        this.rows = new Array();
    }
}
exports.DataTable = DataTable;
class Column {
}
exports.Column = Column;

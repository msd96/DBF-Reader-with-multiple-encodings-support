export declare class DataTable {
    columns: Array<Column>;
    rows: Array<any>;
    constructor();
}
export declare class Column {
    name: string;
    type: string;
}
